========================================
 celery.task.http
========================================

.. contents::
    :local:
.. currentmodule:: celery.task.http

.. automodule:: celery.task.http
    :members:
    :undoc-members:
