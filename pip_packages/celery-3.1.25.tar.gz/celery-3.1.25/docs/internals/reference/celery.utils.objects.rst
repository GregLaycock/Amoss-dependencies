==================================================
 celery.utils.objects
==================================================

.. contents::
    :local:
.. currentmodule:: celery.utils.objects

.. automodule:: celery.utils.objects
    :members:
    :undoc-members:
