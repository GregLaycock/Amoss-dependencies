====================================
 celery.worker.loops
====================================

.. contents::
    :local:
.. currentmodule:: celery.worker.loops

.. automodule:: celery.worker.loops
    :members:
    :undoc-members:
