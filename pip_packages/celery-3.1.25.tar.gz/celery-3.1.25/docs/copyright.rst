Copyright
=========

*Celery User Manual*

by Ask Solem

.. |copy|   unicode:: U+000A9 .. COPYRIGHT SIGN

Copyright |copy| 2009-2015, Ask Solem.

All rights reserved.  This material may be copied or distributed only
subject to the terms and conditions set forth in the `Creative Commons
Attribution-ShareAlike 4.0 International`
<http://creativecommons.org/licenses/by-nc-sa/3.0/us/>`_ license.

You may share and adapt the material, even for commercial purposes, but
you must give the original author credit.
If you alter, transform, or build upon this
work, you may distribute the resulting work only under the same license or
a license compatible to this one.

.. note::

   While the *Celery* documentation is offered under the
   Creative Commons *Attribution-ShareAlike 4.0 International* license
   the Celery *software* is offered under the
   `BSD License (3 Clause) <http://www.opensource.org/licenses/BSD-3-Clause>`_
