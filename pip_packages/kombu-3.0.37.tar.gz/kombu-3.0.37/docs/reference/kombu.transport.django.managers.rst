==========================================================
 Django Managers - kombu.transport.django.managers
==========================================================

.. contents::
    :local:
.. currentmodule:: kombu.transport.django.managers

.. automodule:: kombu.transport.django.managers
    :members:
    :undoc-members:
