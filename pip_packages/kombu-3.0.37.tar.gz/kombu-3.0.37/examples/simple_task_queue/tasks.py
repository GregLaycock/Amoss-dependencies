def hello_task(who="world"):
    print("Hello %s" % (who, ))
