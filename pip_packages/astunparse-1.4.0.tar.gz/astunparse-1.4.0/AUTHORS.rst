=======
Credits
=======

Maintainer
----------

* Simon Percivall <percivall@gmail.com>

Authors
-------

* The Python Software Foundation
* Bogdan Opanchuk
