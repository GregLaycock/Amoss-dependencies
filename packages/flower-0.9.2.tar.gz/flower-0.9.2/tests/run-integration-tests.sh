#!/bin/bash
set -e

python -m tests.unit.__main__
